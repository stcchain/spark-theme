<?php
/*
Plugin Name: Spark Theme Support
Plugin URI: http://themes.themeextra.com/spark
Description: This plugin is compatible with Spark WHMCS hosting theme
Author: Ohidul
Author URI: http://ohidul.com
Version: 2.2.1
Text Domain: spark-theme
*/


/*=============================================
=            LADING PLUGIN TEXTDOMAIN         =
=============================================*/

add_action( 'init', 'spark_ts_textdomain' );

function spark_ts_textdomain() {
  load_plugin_textdomain( 'spark-theme', false, basename( dirname( __FILE__ ) ) . '/languages' );
}



// Theme Custom Post Types
require_once plugin_dir_path(__FILE__) . 'theme-custom-post-types.php';


// Theme Shortcodes
require_once plugin_dir_path(__FILE__) . '/theme-shortcodes.php';
