<?php 




if( ! class_exists('sparkTeamMember') ) {

	class sparkTeamMember extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_team_member', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts, $content = null ) {
			extract( shortcode_atts( array (
				'name' => 'James Martin',
				'job_title' => 'Web Experts',
				'image' => '',
				'about' => 'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse mol estie consequat, vel illum.',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts ) );


			// Get the attachment image
	        $img = wp_get_attachment_image_src( $image );

	        $output =  '<div class="singleTeam wow '. esc_attr($animation_name) .'"
		        			data-wow-duration="'. esc_attr($animation_duration) .'" 
		        			data-wow-delay="'. esc_attr($animation_delay) .'"
		        		>
    					<div class="teamImg">';
			
			$output .= '<img src="'. esc_url($img[0]) .'" alt=""></div>';

			$output .= 	'<div class="teamContent">
    						<div class="memberName h4">'. esc_attr($name) .'</div>';
    		$output .=	'<span class="position">'. esc_attr($job_title) .'</span>
    						<div class="teamTxt">';
    		$output .=	'<p>'. esc_html($about) .'</p>';

    		$output .=	'</div>
    					</div>
    				</div>';
	                    
			return $output;
		}


	}
}

$teamMemberInstance = new sparkTeamMember;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Team Member", "spark-theme"),
		'base' => 'spark_team_member',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Place single team member", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => __("Name", "spark-theme"),
				'param_name' => 'name',
				'value' => 'Team member name'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Job title", "spark-theme"),
				'param_name' => 'job_title',
				'value' => 'Web Experts'
			),
			array(
				'type' => 'attach_image',
				'heading' => __("Team member Image", "spark-theme"),
				'param_name' => 'image',
			),
			array(
				'type' => 'textarea',
				'heading' => __("About", "spark-theme"),
				'param_name' => 'about',
				'value' => 'About the team member.'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $teamMemberInstance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}

