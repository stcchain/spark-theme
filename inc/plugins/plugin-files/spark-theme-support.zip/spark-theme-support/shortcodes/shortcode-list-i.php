<?php 




if( ! class_exists('SparkListI') ) {

	class SparkListI extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_list_i', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'lists' => '',
				'text' => '',
				'icon' => '',
				'icon_color' => '',
				'icon_bg_color' => '',
			), $atts ) );

			if( function_exists('vc_param_group_parse_atts') ) {
				$lists = vc_param_group_parse_atts($lists);				
			}


            $output = '<ul class="spark_list_i">';

			    if(  count( $lists ) ) :
				    foreach( $lists as $list ) :
				    	$output .= '<li>';
					    if(  ! empty($list['icon']) ) {
			    			$output .= '<i style="background-color: '. $icon_bg_color .';color: '. $icon_color .';" class="'. esc_attr($list['icon']) .'"></i>' ;
				        }
				    	$output .=  esc_html( $list['text'] );
				    	$output .= '</li>';
				    endforeach;
				endif;

			$output .= '</ul>';
	                    
			return $output;

			
		}


	}
}

$searchDomain1Instance = new SparkListI;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark List", "spark-theme"),
		'base' => 'spark_list_i',
		'category' => __("Spark", "spark-theme"),
		'description' => __("This list items with icons.", "spark-theme"),
		'params' => array( 
			// params group
            array(
                'type' => 'param_group',
                'heading' => 'Lists',
                'value' => '',
                'param_name' => 'lists',
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => 'List item text',
                        'param_name' => 'text',
                        'heading' => 'Enter list item text',
                    ),
                    array(
                        'type' => 'iconpicker',
                        'param_name' => 'icon',
                        'heading' => 'Choose icon.',
                    ),
                )
            ),
			array(
				'type' => 'colorpicker',
				'heading' => __("Icon Color", "spark-theme"),
				'param_name' => 'icon_color',
				'value' => '#000'
			),

			array(
				'type' => 'colorpicker',
				'heading' => __("Icon Background Color", "spark-theme"),
				'param_name' => 'icon_bg_color',
				'value' => '#39b129'
			),
		)
	) );
}

