<?php




if( ! class_exists('SparkButton') ) {

	class SparkButton extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_btn', array($this, 'shortcode_render_func') );
			add_shortcode( 'spark_simple_btn', array($this, 'simple_btn_shortcode_render_func') );
			add_action( 'wp_enqueue_scripts', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'text' => 'Button text',
				'link' => '#',
				'icon' => '',
				'font_size' => '13px',
				'padding' => '14px',
				'margin' => '0px',
				'bg_color' => '#288feb',
				'bg_hover_color' => '#3FA5FF',
				'btn_color' => '#fff',
				'btn_hover_color' => '#fff',
				'extra_class' => '',
				'align' => 'left',
				'style' => 'round',
				'underline' => '#000',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts ) );

	        $output =  '<a href="'. esc_attr($link) .'"
	        				class=" spark-btn wow '. esc_attr($animation_name) . ' ' . esc_attr($style) . ' ' . esc_attr($extra_class) . '  "
	        				data-spark-btn-bg-color="'. esc_attr($bg_color) .'"
	        				data-spark-btn-bg-hover-color="'. esc_attr($bg_hover_color) .'"
	        				data-spark-btn-color="'. esc_attr($btn_color) .'"
	        				data-spark-btn-hover-color="'. esc_attr($btn_hover_color) .'"
	        				style=";
	        						background-color: '. esc_attr($bg_color) .';
	        						color: '. esc_attr($btn_color) .';
	        						font-size: '. esc_attr($font_size) .';
	        						float: '. esc_attr($align) .';
	        						margin: '. esc_attr($margin) .';
	        						padding: '. esc_attr($padding) .';"
	        				data-wow-delay="'. esc_attr($animation_delay) . '"
	        				data-wow-duration="'. esc_attr($animation_duration) . '"

	        			>';
	        if(  ! empty($icon) ) {
    			$output .= '<i class="'. esc_attr($icon) .'"></i>' ;
	        }
    		$output .= esc_html($text) ;
    		$output .= '</a>';

			return $output;
		}

		public function simple_btn_shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'text' => 'Button text',
				'link' => '#',
				'background' => '#fff',
				'font_size' => '13px',
				'padding' => '14px',
				'margin' => '0px',
				'button_style' => 'btn_style_1',
				'color' => '#fff',
				'extra_class' => '',
				'align' => 'left',
				'style' => 'round',
				'underline' => '#000',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts ) );

	        $output =  '<a href="'. esc_attr($link) .'"
	        				class="'. esc_attr($button_style) .' spark-btn "
	        				style=";
	        						background: '. esc_attr($background) .';
	        						color: '. esc_attr($color) .';
	        						font-size: '. esc_attr($font_size) .';
	        						float: '. esc_attr($align) .';
	        						margin: '. esc_attr($margin) .';
	        						padding: '. esc_attr($padding) .';"
	        			>';

    		$output .= esc_html($text) ;
    		$output .= '</a>';

			return $output;
		}


	}
}

$buttonInstance = new SparkButton;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Button", "spark-theme"),
		'base' => 'spark_btn',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Add a button and style your own", "spark-theme"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => __("Text", "spark-theme"),
				'param_name' => 'text',
				'description' => __("The text of the button", "spark-theme"),
				'value' => __('Button text', "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Url", "spark-theme"),
				'param_name' => 'link',
				'description' => __("The url link of the button", "spark-theme"),
			),
			array(
				'type' => 'textfield',
				'heading' => __("Font size", "spark-theme"),
				'param_name' => 'font_size',
				'description' => __("Set the font size", "spark-theme"),
				'std' => '13px',
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Background Color", "spark-theme"),
				'param_name' => 'bg_color',
				'description' => __("Set the background color", "spark-theme"),
				'std' => '#288feb',
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Background Hover Color", "spark-theme"),
				'param_name' => 'bg_hover_color',
				'description' => __("Set the background hover color", "spark-theme"),
				'std' => '#3FA5FF',
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Color", "spark-theme"),
				'param_name' => 'btn_color',
				'description' => __("Set the button text  color", "spark-theme"),
				'std' => '#fff',
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Hover Color", "spark-theme"),
				'param_name' => 'btn_hover_color',
				'description' => __("Set the button text hover color", "spark-theme"),
				'std' => '#fff',
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Style", "spark-theme"),
				'param_name' => 'style',
				'value' => array(
					'Round' => 'round',
					'Square' => 'square',
					'Rounded' => 'rounded',
				),
				'description' => __("Set the button style", "spark-theme"),
				'std' => 'round'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Align", "spark-theme"),
				'param_name' => 'align',
				'value' => array(
					'Left'	=> 'left',
					'Right'	=> 'right'
				),
				'description' => __("Set the button alignment", "spark-theme"),
				'std' => 'left'
			),
			array(
				'type' => 'iconpicker',
				'heading' => __("Icon", "spark-theme"),
				'param_name' => 'icon',
				'description' => __("Choose the icon", "spark-theme"),
			),
			array(
				'type' => 'textfield',
				'heading' => __("Margin", "spark-theme"),
				'param_name' => 'margin',
				'description' => __("Set the margin", "spark-theme"),
				'std' => '0px',
			),
			array(
				'type' => 'textfield',
				'heading' => __("Padding", "spark-theme"),
				'param_name' => 'padding',
				'description' => __("Set the padding", "spark-theme"),
				'std' => '15px',
			),
			array(
				'type' => 'textfield',
				'heading' => __("Extra class name", "spark-theme"),
				'param_name' => 'extra_class',
				'description' => __("Give extra class name if needed", "spark-theme"),
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $paragraphInstance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}
