<?php 




if( ! class_exists('SparkFAQ') ) {

	class SparkFAQ extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_faq', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'question' => 'The question here',
				'answer' => 'The answer here'
			), $atts ) );


	        $output =  '<div class="singleFaq animated">';
    		$output .=	'<div class="faqTitle">'. esc_html($question) .'</div>
    					<p>'. esc_html($answer) .'</p>';
    		$output .= '</div>';
	                    
			return $output;
		}


	}
}

$faqInstance = new SparkFAQ;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark FAQ", "spark-theme"),
		'base' => 'spark_faq',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Frequently Asked Question section ", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => __("Question", "spark-theme"),
				'param_name' => 'question',
				'description' => __("The question title of FAQ", "spark-theme"),
				'value' => __('Question here', 'spark-theme')
			),
			array(
				'type' => 'textarea',
				'heading' => __("Answer", "spark-theme"),
				'param_name' => 'answer',
				'description' => __("The answer text of FAQ", "spark-theme"),
				'std' => __('Answer here', 'spark-theme')
			),
		)
	) );
}

