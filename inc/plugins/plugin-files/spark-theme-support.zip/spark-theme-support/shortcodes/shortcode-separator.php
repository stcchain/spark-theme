<?php 




if( ! class_exists('SparkSeparator') ) {

	class SparkSeparator extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_separator', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'color' => '#EAEAEA',
				'height' => '1px',
			), $atts ) );


	        $output =  '<div class="sectionBar" style="background-color: '. esc_attr($color) . '; height: '. esc_attr($height) .'"></div>';
	                    
			return $output;
		}


	}
}

$separatorInstance = new SparkSeparator;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Separator", "spark-theme"),
		'base' => 'spark_separator',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Place a separator", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'colorpicker',
				'heading' => __("Border color", "spark-theme"),
				'param_name' => 'color',
				'description' => __("Choose the border color", "spark-theme"),
				'value' => '#EAEAEA'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Height", "spark-theme"),
				'param_name' => 'height',
				'description' => __('Height of the separator', 'spark-theme'),
				'std' => '1px'
			),
		)
	) );
}

