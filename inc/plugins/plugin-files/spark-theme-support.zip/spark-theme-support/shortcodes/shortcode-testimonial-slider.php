<?php 




if( ! class_exists('SparkTestimonialSlider') ) {

	class SparkTestimonialSlider extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_testimonial_slider', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts, $content = null ) {
			extract( shortcode_atts( array (
				'load' => -1,
				'grid' => '12'
			), $atts ) );

			$content = wpb_js_remove_wpautop($content, true);

			// Query for all the testimonials
			$args = array(
				'post_type'	=> 'testimonial',
				'posts_per_page'	=> $load,
			);

			$posts = new WP_Query( $args );

			if( $posts->have_posts() ) :

				$output = '<div class="tstSlider owl-carousel">';

				while( $posts->have_posts() ) :
					$posts->the_post();

				// Get post meta values
				$testimonial = get_post_meta( get_the_ID(), 'spark_testimonial_description', true);
				$url = get_post_meta( get_the_ID(), 'spark_testimonial_url', true);

			        $output .=  '<div class="col-sm-12 singleTstSlide">
										<div class="singleTst">
											<p>“'. esc_attr($testimonial) .'”</p>
											<span class="clientName">'. esc_html(get_the_title()) .'</span>
											<a href="#">'. esc_url($url ).'</a>
										</div>
				    				</div>
				    			';
	            	
				endwhile;
				
	            $output .= '</div>';	

				wp_reset_postdata();
			else:

	        	$output =  '<div class="col-sm-12 singleTstSlide">
								<div class="singleTst">
									<p>“Sorry, no testimonial posts found to show”</p>
								</div>
		    				</div>';
			endif;
	                    
			return $output;
		}


	}
}

$testimonialSliderInstance = new SparkTestimonialSlider;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Testimonial Slider", "spark-theme"),
		'base' => 'spark_testimonial_slider',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Place testimonials loads from testimonial custom post", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => __("Number of testimonial to show", "spark-theme"),
				'param_name' => 'load',
				'description' => __('Set the number of posts, and if you want to load unlimited posts set it -1', 'spark-theme'),
				'std' => -1
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Grid", "spark-theme"),
				'param_name' => 'grid',
				'value'	=> array(
					'3/3' => '12',
					'2/3' => '6',
					'1/3' => '4',
				),
				'description' => __('Select the grid to show for all testimonials.', 'spark-theme'),
			),
		)
	) );
}

