<?php 




if( ! class_exists('SparkClouds') ) {

	class SparkClouds extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_clouds', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'images' => '',
			), $atts ) );

			// Get the images string
			$imgs = explode(',', $images);

			$output = '<div class="clouds">';

				$int = 1;

				// Iterate through all the images
				foreach( $imgs as $image) {
					// Get the image sourch
					$img = wp_get_attachment_image_src($image);

					// Output all the images
					$output .= '<img src="'. esc_url($img[0]) .'" alt="" class="cloud'. $int .'">';				
					$int++;
				}

			$output .= '</div>';
	                    
			return $output;
		}


	}
}

$cloudsInstance = new SparkClouds;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Clouds", "spark-theme"),
		'base' => 'spark_clouds',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Set images for the clouds", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'attach_images',
				'heading' => __("Select images", "spark-theme"),
				'param_name' => 'images',
				'description' => __('Select cloud images', 'spark-theme'),
			),
		)
	) );
}

