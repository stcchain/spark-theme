<?php 




if( ! class_exists('SparkSearchDomain2') ) {

	class SparkSearchDomain2 extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_domain_checker_2', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'input_placeholder' => 'Enter your domain name here',
				'button_value' => 'Search',
				'spark_domain_tlds' => '',
				'domain_name' => 'com',
				'domain_checked' => '',
			), $atts ) );


			if( function_exists('vc_param_group_parse_atts') ) {
				$spark_domain_tlds = vc_param_group_parse_atts($spark_domain_tlds);				
			}

            $output = '<div id="domain-form2" class="domainSearchArea ">
            			<form action="./" class="domainForm domainSearchForm  " method="post">
						    <div class="domainTop">

						        <input type="search" autocomplete="off" id="Search" name="domain" placeholder="'. esc_attr($input_placeholder) .'">
						        <button type="submit" class="submit">
									<span class="hide-it loader"><i class="fa fa-cog fa-spin"></i></span>
									'. esc_attr($button_value) .' 
						        </button>
						    </div>
						    
						    <div class="domainCheck">';


						    if(  count( $spark_domain_tlds ) ) :
							    foreach( $spark_domain_tlds as $domain_tld ) :
							    
							    	$output .=	'<span class="com">
							        	<input type="radio" class="domainTLD" name="domainTLD" value="'. esc_html( $domain_tld["domain_name"] ) .'" id="'. esc_html( $domain_tld["domain_name"] ) .'"';
										if( isset($domain_tld['domain_checked']) && $domain_tld['domain_checked'] == 'true' ) :
											$output .= 'checked';
										endif;
							        $output .=	'> .'. esc_html( $domain_tld["domain_name"] ) . '<label for="'. esc_html( $domain_tld["domain_name"] ) .'"></label>
							        </span>';

							    endforeach;
							else:


						    $output .=     '<span class="com">
						        	<input type="radio" class="domainTLD" name="domainTLD" value="com" checked> .com  
						        	<label for="com"></label>
						        </span>

						        <span class="net">
						        	<input type="radio" class="domainTLD" name="domainTLD" value="net" > .net 
						        	<label for="net"></label>
						        </span>

						        <span class="org">
						        	<input type="radio" class="domainTLD" name="domainTLD" value="org"> 
						        	.org 
						        	<label for="org"></label>
						        </span>

						        <span class="in">
						        	<input type="radio" class="domainTLD" name="domainTLD" value="in"> .in 
						        	<label for="in"></label>
						        </span>';

							endif;

						$output .= '</div>
							</form>
							<p>
								<div id="results" class="result"></div>
							</p>
						</div>

					<div class="select-domain"></div>';
	                    
			return $output;
		}


	}
}

$searchDomain2Instance = new SparkSearchDomain2;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Domain Checker 2", "spark-theme"),
		'base' => 'spark_domain_checker_2',
		'category' => __("Spark", "spark-theme"),
		'description' => __("This will add a static domain search form.", "spark-theme"),
		'params' => array( 
			// params group
            array(
                'type' => 'param_group',
                'heading' => 'Domain TLD',
                'value' => '',
                'param_name' => 'spark_domain_tlds',
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => 'com',
                        'param_name' => 'domain_name',
                        'heading' => 'Enter domain TLD with dot before. n.b. com, net, org, de, in',
                    ),
                    array(
                        'type' => 'checkbox',
                        'value' => '',
                        'param_name' => 'domain_checked',
                        'heading' => 'Check this item for automatically checked on page.',
                    ),
                )
            ),
			array(
				'type' => 'textfield',
				'heading' => __("Input placeholder", "spark-theme"),
				'param_name' => 'input_placeholder',
				'description' => __("Enter placeholder text of the input form", "spark-theme"),
				'value' => 'Enter your domain name here'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Button value", "spark-theme"),
				'param_name' => 'button_value',
				'description' => __("Enter button value text", "spark-theme"),
				'value' => 'Search'
			),
		)
	) );
}

