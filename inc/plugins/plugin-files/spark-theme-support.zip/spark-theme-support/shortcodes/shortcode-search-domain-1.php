<?php




if( ! class_exists('SparkSearchDomain1') ) {

	class SparkSearchDomain1 extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_domain_checker', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'input_placeholder' => 'Enter your domain name here',
				'button_value' => 'Search',
				'spark_domain_tlds' => '',
				'domain_name' => 'com',
				'domain_checked' => '',
				'dc_style' => '',
				'btn_bg_color' => '',
				'buy_now_btn' => 'Buy now',
				'buy_now_btn_style' => 'whmcs_link',
				'custom_link' => '#',
			), $atts ) );

			if( function_exists('vc_param_group_parse_atts') ) {
				$spark_domain_tlds = vc_param_group_parse_atts($spark_domain_tlds);
			}

			$dc_classes = array();

			$buy_now_btn_options = array(
				'buy_now_btn_text' => $buy_now_btn,
				'buy_now_btn_style' => $buy_now_btn_style,
				'custom_link' => $custom_link,
			);

			$buy_now_btn_options = json_encode($buy_now_btn_options);

			if( $dc_style == 'style2' ) {
				$dc_classes[] = 'dcwrapper_style2 ';
			}

            $output = '<div class="'. implode(' ', $dc_classes) .'">
            			<div id="domain-form" class="domainchecker" data-options=\''. $buy_now_btn_options .'\'>
            			<form action="./" class="domainForm" method="post">
						    <div class="domainTop">

						        <input type="search" autocomplete="off" id="Search" name="domain" placeholder="'. esc_attr($input_placeholder) .'">';


						       	if( $dc_style !== 'style2' ) :

							    	$output .=  '<button type="submit" class="submit" style="background-color:'. $btn_bg_color .'">
													<span class="hide-it loader"><i class="fa fa-cog fa-spin"></i></span>
													'. esc_attr($button_value) .'
									        	</button>';
						        endif;

			$output .=     '</div>

						    <div class="domainCheck">';


						    if(  count( $spark_domain_tlds ) ) :
							    foreach( $spark_domain_tlds as $domain_tld ) :

							    	$output .=	'<span class="com">
							        	<input type="radio" class="domainTLD" name="domainTLD" value="'. esc_html( $domain_tld["domain_name"] ) .'" id="'. esc_html( $domain_tld["domain_name"] ) .'"';
										if( isset($domain_tld['domain_checked']) && $domain_tld['domain_checked'] == 'true' ) :
											$output .= 'checked';
										endif;
							        $output .=	'> .'. esc_html( $domain_tld["domain_name"] ) . '<label for="'. esc_html( $domain_tld["domain_name"] ) .'"></label>
							        </span>';

							    endforeach;
							else:


								$output .=     '<span class="com">
										        	<input type="radio" class="domainTLD" name="domainTLD" value="com" id="com" checked> .com
										        	<label for="com"></label>
										        </span>

										        <span class="net">
										        	<input type="radio" class="domainTLD" name="domainTLD"  id="net" value="net" > .net
										        	<label for="net"></label>
										        </span>

										        <span class="org">
										        	<input type="radio" class="domainTLD" name="domainTLD" id="org" value="org">
										        	.org
										        	<label for="org"></label>
										        </span>

										        <span class="in">
										        	<input type="radio" class="domainTLD" name="domainTLD" id="in" value="in"> .in
										        	<label for="in"></label>
										        </span>';

							endif;

						$output .=    '</div><p>
									<div id="results" class="result"></div>
								</p>';


						       	if( $dc_style == 'style2' ) :

							    	$output .=  '<div><button type="submit" class="submit dc_style2 "  style="background-color:'. $btn_bg_color .'">
													<span class="hide-it loader"><i class="fa fa-cog fa-spin"></i></span>
													'. esc_attr($button_value) .'
									        	</button></div>';
						        endif;

					$output .='</form>

							</div>

					<div class="select-domain"></div></div>';

			return $output;


		}


	}
}

$searchDomain1Instance = new SparkSearchDomain1;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Domain Checker", "spark-theme"),
		'base' => 'spark_domain_checker',
		'category' => __("Spark", "spark-theme"),
		'description' => __("This will add a static domain search form.", "spark-theme"),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => __("Domain Checker Style", "spark-theme"),
				'param_name' => 'dc_style',
				'description' => __("Select the domain checker style", "spark-theme"),
				'value' => array(
					'Style 1'	=> 'style1',
					'Style 2'	=> 'style2',
				),
				'std' => 'style1'
			),
			// params group
            array(
                'type' => 'param_group',
                'heading' => 'Domain TLD',
                'value' => '',
                'param_name' => 'spark_domain_tlds',
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'value' => 'com',
                        'param_name' => 'domain_name',
                        'heading' => 'Enter domain TLD with dot before. n.b. com, net, org, de, in',
                    ),
                    array(
                        'type' => 'checkbox',
                        'value' => '',
                        'param_name' => 'domain_checked',
                        'heading' => 'Check this item for automatically checked on page.',
                    ),
                )
            ),
			array(
				'type' => 'textfield',
				'heading' => __("Input placeholder", "spark-theme"),
				'param_name' => 'input_placeholder',
				'description' => __("Enter placeholder text of the input form", "spark-theme"),
				'value' => 'Enter your domain name here'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Button value", "spark-theme"),
				'param_name' => 'button_value',
				'description' => __("Enter button value text", "spark-theme"),
				'value' => 'Search'
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Button Color", "spark-theme"),
				'param_name' => 'btn_bg_color',
				'description' => __("Choose button color", "spark-theme"),
				'value' => '#288feb'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Title for buy now button", "spark-theme"),
				'param_name' => 'buy_now_btn',
				'description' => __("Enter text for buy now button.", "spark-theme"),
				'value' => 'But now'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Choose buy now button function", "spark-theme"),
				'param_name' => 'buy_now_btn_style',
				'description' => __("Choose the function on buy now button.", "spark-theme"),
				'value' => array(
					'WHMCS Link' => 'whmcs_link',
					'Custom Link' => 'custom_link',
				)
			),
			array(
				'type' => 'textfield',
				'heading' => __("Custom link for buy now button", "spark-theme"),
				'param_name' => 'custom_link',
				'description' => __("Enter custom link for buy now button.", "spark-theme"),
				'dependency' => array(
					"element" => "buy_now_btn_style",
					"value" => "custom_link"
				),
				'value' => '#'
			),
		)
	) );
}
