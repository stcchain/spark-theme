<?php 




if( ! class_exists('SparkTstSlider2') ) {

	class SparkTstSlider2 extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_tst_slider2', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'post_type'	=> 'testimonial',
				'position'	=> '',
				'top'	=> '0px',
				'bottom'	=> '0px',
				'load' => -1,
			), $atts ) );

			$styles = '';

			if( $position ) {
				$styles .= 'position: '. $position .';';
			}
			if( $top ) {
				$styles .= 'top: '. $top . ';';
			}
			if( $bottom ) {
				$styles .= 'bottom: '. $bottom . ';';
			}



			// Query for all the testimonials
			$args = array(
				'post_type'	=> 'testimonial',
				'posts_per_page'	=> $load,
			);

			$posts = new WP_Query( $args );

			if( $posts->have_posts() ) :


	            $output = '<div class="spark_tst_slider2 owl-carousel owl-theme" style="'. esc_attr( $styles ) .'">';

	        		while( $posts->have_posts() ) :
					$posts->the_post();

					// Get post meta values
					$testimonial_img = get_post_meta( get_the_ID(), 'spark_testimonial_a_img', true);
					$testimonial = get_post_meta( get_the_ID(), 'spark_testimonial_description', true);
					$url = get_post_meta( get_the_ID(), 'spark_testimonial_url', true);

				    $output .= '<div class="item">';
				    		if( $testimonial_img ) :
								$output .=	'<img src="'. esc_url( $testimonial_img ) .'" alt="image">';
							else:
								$output .=	'<img src="'. get_template_directory_uri() .'/img/user-image.png" alt="'. esc_html( get_the_title() ) .'">';
							endif;
						$output .= '<p class="tst_content">“'. $testimonial .'”</p>
									<h3 class="author">'. esc_html( get_the_title() ) .'</h3>
									<a class="site_url" href="'. esc_url( $url ).'">'. esc_url( $url ).'</a>
				    			</div>';


				endwhile;
				
	            $output .= '</div>';	

				wp_reset_postdata();

			
	        else:

	        	$output =  '<div class="col-md-6 col-md-offset-3">
            				<div class="singleTst animated">
            					<p>“Sorry, no testimonial posts found to show”</p>
            				</div>
            			</div>';
			endif;

			return $output;

			
		}


	}
}

$searchDomain1Instance = new SparkTstSlider2;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Testimonial Slider Style: 2", "spark-theme"),
		'base' => 'spark_tst_slider2',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Add testimonials in a creative way in slider", "spark-theme"),
		'params' => array( 
	
			array(
				'type' => 'textfield',
				'heading' => __("Number of testimonial to show", "spark-theme"),
				'param_name' => 'load',
				'description' => __('Set the number of posts, and if you want to load unlimited posts set it -1', 'spark-theme'),
				'std' => -1
			),
			array(
				'type' => 'textfield',
				'heading' => __("Position", "spark-theme"),
				'description' => __("Use positioning for wrapper, e.g. absolute, relative", "spark-theme"),
				'param_name' => 'position',
				'value' => ''
			),
			array(
				'type' => 'textfield',
				'heading' => __("Top", "spark-theme"),
				'description' => __("Position in top", "spark-theme"),
				'param_name' => 'top',
				'value' => '0px'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Bottom", "spark-theme"),
				'description' => __("Position in bottom", "spark-theme"),
				'param_name' => 'bottom',
				'value' => '0px'
			),

		)
	) );
}

