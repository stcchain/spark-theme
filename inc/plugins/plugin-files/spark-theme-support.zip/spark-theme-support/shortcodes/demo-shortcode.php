<?php 


if( ! class_exists('SparkGoogleMap') ) {


	class SparkGoogleMap extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_google_map', array($this, 'shortcode_render_func') );
		}

		public function shortcode_render_func( $atts )
		{
		    extract( shortcode_atts( array(
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
		    ), $atts ) )
		}
	}
}


$sparkGoogleMap = new SparkGoogleMap;


if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Google Map", "spark-theme"),
		'base' => 'spark_google_map',
		'category' => __("Content", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => 'Give simple title',
				'param_name' => 'sample_title'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $sparkGoogleMap->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}