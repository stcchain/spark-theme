<?php




if( ! class_exists('SparkParagraph') ) {

	class SparkParagraph extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_paragraph', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts) {
			extract( shortcode_atts( array (
				'paragraph' => 'Lorem imsum dolor sit amet.',
				'font_size' => '15px',
				'color' => '#000',
				'line_height' => '18px',
				'align' => 'center',
				'choose_font_family' => 'theme_font',
				'default_font_family' => 'proxima_nova_rgregular',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts ) );


	        $output =  '<p style="
	        		font-size:'. esc_attr($font_size) . ';';

					if( $choose_font_family == 'theme_font' ) {
					   $output .= 'font-family:' . esc_attr( $default_font_family ) . ';';
				   }

	       $output .= 'text-align:'. esc_attr($align) .';
	        		color:'. esc_attr($color) .';
	        		line-height:'. esc_attr($line_height) .'"
	        		class=" wow '. esc_attr($animation_name) .'"
	        		data-wow-duration="'. esc_attr($animation_duration) .'"
	        		data-wow-delay="'. esc_attr($animation_delay) .'"
	        		>';
	        $output .=   esc_html($paragraph);
	        $output .=  '</p>';

			return $output;
		}


	}
}

$paragraphInstance = new SparkParagraph;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Paragraph", "spark-theme"),
		'base' => 'spark_paragraph',
		'category' => __("Spark", "spark-theme"),
		'description' => __("This give you a way of adding paragraph text and styling.", "spark-theme"),
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => __("Paragraph text", "spark-theme"),
				'param_name' => 'paragraph',
				'description' => __("The text of the paragraph", "spark-theme"),
				'std' => 'Lorem imsum dolor sit amet'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Font size", "spark-theme"),
				'param_name' => 'font_size',
				'description' => __("Set the font size", "spark-theme"),
				'std' => '15px'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Line height", "spark-theme"),
				'param_name' => 'line_height',
				'description' => __("Set the line height", "spark-theme"),
				'std' => '18px'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Choose font family", "spark-theme"),
				'param_name' => 'choose_font_family',
				'description' => __("Choose the font family", "spark-theme"),
				'value' => array(
					'Use theme default font' => 'theme_font',
					'Use from Theme Options' => 'inherit',
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Font Weight", "spark-theme"),
				'param_name' => 'default_font_family',
				'description' => __("The theme defualt font family will apply by default. You just need to set the font weight", "spark-theme"),
				'value' => array(
					'Bold' => 'proxima_nova_rgbold',
					'Semi bold' => 'proxima_novasemibold',
					'Regular' => 'proxima_nova_rgregular',
					'Light' => 'proxima_novalight'
				),
				'std' => 'proxima_nova_rgregular',
				"dependency" => Array('element' => "choose_font_family", 'value' => array('theme_font'))
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Color", "spark-theme"),
				'param_name' => 'color',
				'description' => __("Stylize the color", "spark-theme"),
				'std' => '#000'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Align", "spark-theme"),
				'param_name' => 'align',
				'description' => __("Set the button alignment", "spark-theme"),
				'value' => array(
					'Center'	=> 'center',
					'Left'	=> 'left',
					'Right'	=> 'right'
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $paragraphInstance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}
