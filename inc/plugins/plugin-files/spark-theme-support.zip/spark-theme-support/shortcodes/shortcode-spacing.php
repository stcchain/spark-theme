<?php 




if( ! class_exists('SparkEmptySpace') ) {

	class SparkEmptySpace extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_empty_space', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				"height" => "",
				"height_on_tabs" => "",
				"height_on_tabs_portrait" => "",
				"height_on_mob" => "",
				"height_on_mob_landscape" => ""
			), $atts ) );

			$output  = '';
	        if($height_on_mob == "" && $height_on_tabs == "")
				$height_on_mob = $height_on_tabs = $height;
			$style = 'clear:both;';
			$style .= 'display:block;';
			$uid = uniqid();
			$output .= '<div class="spark-spacer spacer-'.$uid.'" data-id="'.$uid.'" data-height="'.$height.'" data-height-mobile="'.$height_on_mob.'" data-height-tab="'.$height_on_tabs.'" data-height-tab-portrait="'.$height_on_tabs_portrait.'" data-height-mobile-landscape="'.$height_on_mob_landscape.'" style="'.$style.'"></div>';

			return $output;
		}


	}
}

$separatorInstance = new SparkEmptySpace;

if( function_exists('vc_map') ) {

	vc_map(
		array(
		   "name" => __("Spark Spacing","spark-theme"),
		   "base" => "spark_empty_space",
		   "category" => "Spark",
		   "description" => __("Adjust space between components.","spark-theme"),
		   "params" => array(
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("<i class='dashicons dashicons-desktop'></i> Desktop", "spark-theme"),
					"param_name" => "height",
					"admin_label" => true,
					"value" => 10,
					"min" => 1,
					"max" => 500,
					"suffix" => "px",
					"description" => __("Enter value in pixels", "spark-theme"),
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("<i class='dashicons dashicons-tablet' style='transform: rotate(90deg);'></i> Tabs", "spark-theme"),
					"param_name" => "height_on_tabs",
					"admin_label" => true,
					"value" => '',
					"min" => 1,
					"max" => 500,
					"suffix" => "px",
					"edit_field_class" => "vc_col-sm-3 vc_column"
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("<i class='dashicons dashicons-tablet'></i> Tabs", "spark-theme"),
					"param_name" => "height_on_tabs_portrait",
					"admin_label" => true,
					"value" => '',
					"min" => 1,
					"max" => 500,
					"suffix" => "px",
					"edit_field_class" => "vc_col-sm-3 vc_column"
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("<i class='dashicons dashicons-smartphone' style='transform: rotate(90deg);'></i> Mobile", "spark-theme"),
					"param_name" => "height_on_mob_landscape",
					"admin_label" => true,
					"value" => '',
					"min" => 1,
					"max" => 500,
					"suffix" => "px",
					"edit_field_class" => "vc_col-sm-3 vc_column"
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => __("<i class='dashicons dashicons-smartphone'></i> Mobile", "spark-theme"),
					"param_name" => "height_on_mob",
					"admin_label" => true,
					"value" => '',
					"min" => 1,
					"max" => 500,
					"suffix" => "px",
					"edit_field_class" => "vc_col-sm-3 vc_column"
				),
			)
		)
	);
}

