<?php 




if( ! class_exists('SparkPositionImage') ) {

	class SparkPositionImage extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_position_image', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'image' => '',
				'hide' => '',
				'width' => '',
				'left' => 'initial',
				'right' => 'initial',
				'top' => 'initial',
				'bottom' => 'initial',
			), $atts ) );

			// Get the image
			$img = wp_get_attachment_image_src( $image );

        	$output =  '<img src="'. esc_url($img[0]) .'" alt=""';
	        	if( $hide == true ) {
	        		$output .= 'class="position_img_small"';
	        	}
        	$output .='style="position: absolute; width:'. esc_attr($width) .'; top:'. esc_attr($top) .'; left:'. esc_attr($left) .'; bottom:'. esc_attr($bottom) .'; right:'. esc_attr($right) .';">';

			return $output;
		}


	}
}

$positionImageInstance = new SparkPositionImage;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Position Image", "spark-theme"),
		'base' => 'spark_position_image',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Position an image", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'attach_image',
				'heading' => __("Select the image", "spark-theme"),
				'param_name' => 'image',
				'description' => __("Choose the image", "spark-theme"),
			),
			array(
				'type' => 'checkbox',
				'heading' => __("Hide on small device", "spark-theme"),
				'param_name' => 'hide',
			),
			array(
				'type' => 'textfield',
				'heading' => __("Width", "spark-theme"),
				'param_name' => 'width',
				'description' => __("Set the size of the image in pixel.", "spark-theme"),
			),
			array(
				'type' => 'textfield',
				'heading' => __("Top", "spark-theme"),
				'param_name' => 'top',
				'description' => __("Top position of the image", "spark-theme"),
				'std' => 'initial'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Right", "spark-theme"),
				'param_name' => 'right',
				'description' => __("Right position of the image", "spark-theme"),
				'std' => 'initial'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Bottom", "spark-theme"),
				'param_name' => 'bottom',
				'description' => __("Bottom position of the image", "spark-theme"),
				'std' => 'initial'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Left", "spark-theme"),
				'param_name' => 'left',
				'description' => __("Left position of the image", "spark-theme"),
				'std' => 'initial'
			),
		)
	) );
}

