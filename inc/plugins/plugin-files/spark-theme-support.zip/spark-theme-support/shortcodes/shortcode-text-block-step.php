<?php 




if( ! class_exists('SparkTextBlockStep') ) {

	class SparkTextBlockStep extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_text_block_step', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'title' => 'Your title text here',
				'description' => 'Lorem imsum dolor sit amet.',
				'number' => '999',
			), $atts ) );


	        $output = '<div class="singleStep">
    					<div class="stepNo">'. esc_attr($number) .'</div>
    					<div class="stepContent">
    						<div class="h4">'. esc_attr($title) .'</div>
    						<p>'. esc_attr($description) .'</p>
    					</div>
    				</div>';
	                    
			return $output;
		}


	}
}

$sparkTextBlockStepInstance = new SparkTextBlockStep;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Step Text Block", "spark-theme"),
		'base' => 'spark_text_block_step',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Place a textblock for about section", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => __("Title", "spark-theme"),
				'param_name' => 'title',
				'std' => 'Your title text here'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Description", "spark-theme"),
				'param_name' => 'description',
				'std' => 'Lorem imsum dolor sit amet.'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Number", "spark-theme"),
				'param_name' => 'number',
				'description' => __("Set the step number here.", "spark-theme"),
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $sparkTextBlockStepInstance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}

