<?php 




if( ! class_exists('SparkImage') ) {

	class SparkImage extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_img', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'src' => '#',
				'alt' => 'Alt text',
			), $atts ) );


	        $output =  '<img src="'. esc_url($src) .'" alt="'. esc_attr($alt) .'">';
	                    
			return $output;
		}


	}
}

$imageInstance = new SparkImage;
