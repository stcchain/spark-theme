<?php 




if( ! class_exists('SparkSlider') ) {

	class SparkSlider extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_slider_i', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'sliders' => '',
				'heading' => '',
				'text' => '',
				'image' => '',
				'use_btn' => '',
				'button' => '',
			), $atts ) );

			if( function_exists('vc_param_group_parse_atts') ) {
				$sliders = vc_param_group_parse_atts($sliders);				
			}


            $output = '<div class="spark_slider2 owl-carousel owl-theme">';

			    if(  count( $sliders ) ) :
				    foreach( $sliders as $slider ) :

				    	$button = vc_build_link($slider['button']);
				    	$img = wp_get_attachment_image_src($slider['image'], 'large');

				    	$output .= '<div class="item">';
					    	$output .= '<div class="slider-right visible-xs">
					    					<img src="'. esc_url( $img[0] ) .'" alt="'. esc_html( $slider['heading'] ) .'">
					    				</div>';
					    	$output .= '<div class="slider-left">
					    						<h2>'.  $slider['heading'] .'</h2>
					    						<p>'. esc_html( $slider['text'] ) .'</p>';
					    		if( $slider['use_btn'] == true ) :
					    			$output .= '<a href="'. esc_html( $button['url'] ) .'" target="'. esc_html( $button['target'] ) .'" class="sliderBtn Btn">'. esc_html( $button['title'] ) .'</a>';
					    		endif;
					    	$output .=	'</div>';
					    	$output .= '<div class="slider-right hidden-xs">
					    					<img src="'. esc_url( $img[0] ) .'" alt="'. esc_html( $slider['heading'] ) .'">
					    				</div>';
				    	$output .= '</div>';
				    endforeach;
				endif;

			$output .= '</div>';
	                    
			return $output;

			
		}


	}
}

$searchDomain1Instance = new SparkSlider;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Slider", "spark-theme"),
		'base' => 'spark_slider_i',
		'category' => __("Spark", "spark-theme"),
		'description' => __("This list items with icons.", "spark-theme"),
		'params' => array( 
			// params group
            array(
                'type' => 'param_group',
                'heading' => 'sliders',
                'value' => '',
                'param_name' => 'sliders',
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'param_name' => 'heading',
                        'heading' => 'Slider Heading',
                        'value' => 'Super speed for your website to impress your visitor.',
                    ),
                    array(
                        'type' => 'textarea',
                        'param_name' => 'text',
                        'heading' => 'Slider Heading',
                        'value' => 'Greatly cottage thought fortune no mention he. Of mr certainty arranging am smallness by conveying.',
                    ),
                    array(
                        'type' => 'attach_image',
                        'param_name' => 'image',
                        'heading' => 'Slider Image',
                    ),
                    array(
                        'type' => 'checkbox',
                        'param_name' => 'use_btn',
                        'heading' => 'Use button',
                    ),
                    array(
                        'type' => 'vc_link',
                        'param_name' => 'button',
                        'heading' => 'Button',
                    ),
                )
            ),
			array(
				'type' => 'colorpicker',
				'heading' => __("Icon Color", "spark-theme"),
				'param_name' => 'icon_color',
				'value' => '#000'
			),

			array(
				'type' => 'colorpicker',
				'heading' => __("Icon Background Color", "spark-theme"),
				'param_name' => 'icon_bg_color',
				'value' => '#39b129'
			),
		)
	) );
}

