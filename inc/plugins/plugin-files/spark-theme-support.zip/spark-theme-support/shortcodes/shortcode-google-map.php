<?php 


if( ! class_exists('SparkGoogleMap') ) {


	class SparkGoogleMap extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_google_map', array($this, 'shortcode_render_func') );
			add_action( 'wp_enqueue_scripts',  array($this, 'spark_shortcode_scripts' ) );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts )
		{
		    extract( shortcode_atts( array(
				'latitude' => '23.088100',
				'longitude' => '89.235005',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
		    ), $atts ) );

		    wp_enqueue_script('mapScript');

		    return '<div id="googleMap" data-lat="'. esc_attr($latitude) .'" data-lng="'. esc_attr($longitude) .'" data-template-dir="'. get_template_directory_uri() .'"></div>';
		}

		public function spark_shortcode_scripts()
		{
		    wp_register_script('mapScript', get_template_directory_uri() . '/js/mapScript.js', array('jquery') );
		}
	}
}


$sparkGoogleMap = new SparkGoogleMap;


if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Google Map", "spark-theme"),
		'base' => 'spark_google_map',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Add stylish google map", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => 'Latitude',
				'description' => __('Latitude of the lcoation', 'spark-theme'),
				'param_name' => 'latitude'
			),
			array(
				'type' => 'textfield',
				'heading' => 'Longitude',
				'description' => __('Longitude of the lcoation', 'spark-theme'),
				'param_name' => 'longitude'
			)
		)
	) );
}