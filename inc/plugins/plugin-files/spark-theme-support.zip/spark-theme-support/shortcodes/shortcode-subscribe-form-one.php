<?php 




if( ! class_exists('SparkSubscribeForm1') ) {

	class SparkSubscribeForm1 extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_subscribe_form_one', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'action' => '#',
			), $atts ) );


	        $output = '<form action="'. esc_url($action) .'" class="newsletter validate" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" target="_blank" novalidate>
	    					<div class="inputWrep">
	    						<input type="email" name="EMAIL" id="mce-EMAIL" placeholder="Enter your email address">
	    						<input type="submit" value="Subscribe now" name="subscribe" id="mc-embedded-subscribe" class="button">
	    					</div>

	    				</form>';

	    	$output .= '<div id="mce-responses" class="clear">
					<div class="response" id="mce-error-response" style="display:none"></div>
					<div class="response" id="mce-success-response" style="display:none"></div>
				</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
			    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_2a518b6246cfa8394d6942a1f_7019e0a71e" tabindex="-1" value=""></div>';

	                    
			wp_enqueue_script( 'mc-validate-form', 'https://s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js', array('jquery') );
			wp_enqueue_script( 'mc-script', get_template_directory_uri() . '/js/mailchimp-script.js', array('jquery') );

			return $output;
		}


	}
}

$SparkSubscribeForm1Instance = new SparkSubscribeForm1;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark MailChimp Subscriber form 1", "spark-theme"),
		'base' => 'spark_subscribe_form_one',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Place a textblock for about section", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => __("Form action URL", "spark-theme"),
				'param_name' => 'action',
				'std' => 'Enter form action URL here'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $SparkSubscribeForm1Instance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}

