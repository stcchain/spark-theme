<?php 




if( ! class_exists('SparkServiceTextBlock2') ) {

	class SparkServiceTextBlock2 extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_service_text_block2', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts ) {
			extract( shortcode_atts( array (
				'title' => 'Your title text here',
				'description' => 'Lorem imsum dolor sit amet.',
				'image' => '',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts ) );

			// Get the attachment image
	        $img = wp_get_attachment_image_src( $image );

	        $output = '<div class="singleService clearfix style-2 wow '. esc_attr($animation_name) .'" data-wow-duration="'. esc_attr($animation_duration) .'" data-wow-delay="'. esc_attr($animation_delay) .'">
                        <div class="serviceIcon">
                            <img src="'. esc_attr($img[0]) .'" alt="">
                        </div>
                        <div class="serviceContent">
                            <span class="h3">'. esc_attr($title) .'</span>
                            <p>'. esc_attr($description) .'</p>
                        </div>
                    </div>';

			return $output;
		}


	}
}

$sparkServiceTextBlock2Instance = new SparkServiceTextBlock2;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Service Text Block: Style 2", "spark-theme"),
		'base' => 'spark_service_text_block2',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Add a text block for service section", "spark-theme"),
		'params' => array( 
			array(
				'type' => 'textfield',
				'heading' => __("Title", "spark-theme"),
				'param_name' => 'title',
				'std' => 'Your title text here'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Description", "spark-theme"),
				'param_name' => 'description',
				'std' => 'Lorem imsum dolor sit amet.'
			),
			array(
				'type' => 'attach_image',
				'heading' => __("Icon", "spark-theme"),
				'param_name' => 'image',
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $sparkServiceTextBlock2Instance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}

