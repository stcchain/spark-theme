<?php




if( ! class_exists('SparkPricing') ) {

	class SparkPricing extends SparkThemeShortcodes {

		public function __construct()
		{
			add_shortcode( 'spark_pricing', array($this, 'shortcode_render_func') );
		}


		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func( $atts, $content = null) {
			extract( shortcode_atts( array (
				'title' => 'Personal',
				'image' => '',
				'price' => '$3',
				'duration' => 'm',
				'highlight' => '',
				'font_weight' => '700',
				'tagline' => 'best for personal use',
				'btn_text' => 'Get started now',
				'href' => '#',
				'bg_color' => '#fff',
				'box_shadow' => 'none',
				'border' => 'none',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts ) );

			// Get the link from vc
			if( function_exists('vc_build_link') ) {
				$href = vc_build_link( $href );
			}

			// get the image
			$img = wp_get_attachment_image_src( $image );

			$styles = '';

			if( $bg_color ) {
				$styles .= 'background-color: '. $bg_color .';';
			}
			if( !empty($box_shadow) && $box_shadow !== 'none' ) {
				$styles .= 'box-shadow: '. $box_shadow . ';';
			}
			if( !empty($border) && $border !== 'none' ) {
				$styles .= 'border: '. $border . ';';
			}

	        $output =  '<div
	        			style="'. esc_attr( $styles ) .'"
	        			class="singlePrice';
	        			if( $highlight == true ) {
	        				$output .= ' active';
	        			}
	        $output .= '">
                            <div class="priceHead">
                                <span class="priceTitle" style="font-weight:'. esc_attr( $font_weight ).'">'. esc_attr($title) .'</span>
                                <div class="priceImg">
                                    <img src="'. esc_url($img[0]) .'" alt="">
                                </div>
                                <div class="currency">'. esc_attr($price) .'<span>/';
            $output .= 					$duration;
            $output .=          '</span></div>
                                <p>'. esc_attr($tagline) .'</p>
                            </div>
                            '. $content .'
                            <a href="'. $href['url'] .'" class="priceBtn Btn" target="'.$href['target'].'" >'. esc_attr($btn_text) .'</a>
                        </div>';

			return $output;
		}


	}
}

$paragraphInstance = new SparkPricing;

if( function_exists('vc_map') ) {

	vc_map( array(
		'name' => __("Spark Pricing", "spark-theme"),
		'base' => 'spark_pricing',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Add pricing tables", "spark-theme"),
		'params' => array(

			array(
				'type' => 'textfield',
				'heading' => __("Title", "spark-theme"),
				'param_name' => 'title',
				'description' => __("Give the title of pricing table", "spark-theme"),
				'std' => 'Personal'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Font Weight", "spark-theme"),
				'param_name' => 'font_weight',
				'description' => __("Set the font weight", "spark-theme"),
				'value' => array(
					'100' => '100',
					'200' => '200',
					'300' => '300',
					'400' => '400',
					'500' => '500',
					'600' => '600',
					'700' => '700',
					'800' => '800',
					'900' => '900',
				),
				'std' => '700',
			),
			array(
				'type' => 'checkbox',
				'heading' => __("Highlight", "spark-theme"),
				'param_name' => 'highlight',
				'description' => __("Make it active and highlighted to attension the  user", "spark-theme"),
			),
			array(
				'type' => 'textarea_html',
				'heading' => __("Features", "spark-theme"),
				'param_name' => 'content',
				'description' => __("Write down the feature lists of pricing", "spark-theme"),
			),
			array(
				'type' => 'attach_image',
				'heading' => __("Icon", "spark-theme"),
				'param_name' => 'image',
				'description' => __("Choose the icon", "spark-theme"),
				'std' => '15px'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Price", "spark-theme"),
				'param_name' => 'price',
				'description' => __("Set the price", "spark-theme"),
				'std' => '$5'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Duration", "spark-theme"),
				'param_name' => 'duration',
				'description' => __("Subscription Duration", "spark-theme"),
				'std'	=> 'm'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Tagline", "spark-theme"),
				'param_name' => 'tagline',
				'description' => __("Give the slogan or tagline", "spark-theme"),
				'std' => 'best for personal use'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Button Title", "spark-theme"),
				'param_name' => 'btn_text',
				'description' => __("Set button title", "spark-theme"),
				'std' => 'Get started now'
			),
			array(
				'type' => 'vc_link',
				'heading' => __("Button", "spark-theme"),
				'param_name' => 'href',
				'description' => __("Set button URL and target", "spark-theme"),
				'std' => '#'
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Background Color", "spark-theme"),
				'param_name' => 'bg_color',
				'description' => __("Select background color of pricing list item", "spark-theme"),
				'std' => '#fff'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Box Shadow", "spark-theme"),
				'param_name' => 'box_shadow',
				'description' => __("Give box shadow CSS style for the pricing list", "spark-theme"),
				'std' => '0 0 2px #288feb'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Border", "spark-theme"),
				'param_name' => 'border',
				'description' => __("Give border CSS style for the pricing list", "spark-theme"),
				'std' => '1px solid #288FEB '
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $paragraphInstance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	) );
}
