<?php
if (!class_exists('sparkSectionTitle'))
{
	class sparkSectionTitle extends SparkThemeShortcodes
	{
		public function __construct()
		{
			add_shortcode('spark_section_title', array(
				$this,
				'shortcode_render_func'
			));
		}

		/**
		 *
		 * The render function of the shortcode
		 *
		 */
		public function shortcode_render_func($atts, $content = null)
		{
			extract(shortcode_atts(array(
				'heading_type' => 'h1',
				'font_size' => '30px',
				'color' => '#000',
				'align' => 'center',
				'line_height' => '40px',
				'choose_font_family' => 'theme_font',
				'default_font_family' => 'proxima_novasemibold',
				'animation_name' => 'fadeIn',
				'animation_delay' => '0.2s',
				'animation_duration' => '1s',
			), $atts));


			$output = '<' . esc_attr($heading_type) . ' style="
	        		font-size:' . esc_attr($font_size) . ';
	        		text-align:' . esc_attr($align) . ';
	        		color:' . esc_attr($color) . ';';

					if( $choose_font_family == 'theme_font' ) {
					   $output .= 'font-family:' . esc_attr( $default_font_family ) . ';';
				   }


	       $output .= 'line-height:' . esc_attr($line_height) . '"
	        		class="wow section_title ' . esc_attr($animation_name) . '"
	        		data-wow-duration="' . esc_attr($animation_duration) . '"
	        		data-wow-delay="' . esc_attr($animation_delay) . '"
	        		>';
			$output.= $content;
			$output.= '</' . esc_attr($heading_type) . '>';

			return $output;
		}
	}
}

$sectionTitleInstance = new sparkSectionTitle;

if (function_exists('vc_map'))
{
	vc_map(array(
		'name' => __("Spark Section  Title", "spark-theme"),
		'base' => 'spark_section_title',
		'category' => __("Spark", "spark-theme"),
		'description' => __("Add a title text and stylize it", "spark-theme"),
		'params' => array(
			array(
				'type' => 'dropdown',
				'heading' => __("Heading Type", "spark-theme"),
				'param_name' => 'heading_type',
				'description' => __("Choose the type of heading you prefer", "spark-theme"),
				'value' => array(
					'Heading 1' => 'h1',
					'Heading 2' => 'h2',
					'Heading 3' => 'h3',
					'Heading 4' => 'h4',
					'Heading 5' => 'h5',
					'Heading 6' => 'h6'
				),
				'std' => 'h1'
			),
			array(
				'type' => 'textarea_html',
				'heading' => __("Title", "spark-theme"),
				'param_name' => 'content',
				'description' => __("Set the title", "spark-theme"),
				'value' => 'Your title  text here'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Font size", "spark-theme"),
				'param_name' => 'font_size',
				'description' => __("Set the font size", "spark-theme"),
				'std' => '30px'
			),
			array(
				'type' => 'textfield',
				'heading' => __("Line height", "spark-theme"),
				'param_name' => 'line_height',
				'description' => __("Set the line height", "spark-theme"),
				'std' => '40px'
			),

			array(
				'type' => 'dropdown',
				'heading' => __("Choose font family", "spark-theme"),
				'param_name' => 'choose_font_family',
				'description' => __("Choose the font family", "spark-theme"),
				'value' => array(
					'Use theme default font' => 'theme_font',
					'Use from Theme Options' => 'inherit',
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Font Weight", "spark-theme"),
				'param_name' => 'default_font_family',
				'description' => __("The theme defualt font family will apply by default. You just need to set the font weight", "spark-theme"),
				'value' => array(
					'Bold' => 'proxima_nova_rgbold',
					'Semi bold' => 'proxima_novasemibold',
					'Regular' => 'proxima_nova_rgregular',
					'Light' => 'proxima_novalight'
				),
				'std' => 'proxima_novasemibold',
				"dependency" => Array('element' => "choose_font_family", 'value' => array('theme_font'))
			),
			array(
				'type' => 'colorpicker',
				'heading' => __("Color", "spark-theme"),
				'param_name' => 'color',
				'description' => __("Stylize with the color", "spark-theme"),
				'std' => '#000'
			),
			array(
				'type' => 'dropdown',
				'heading' => __("Align", "spark-theme"),
				'param_name' => 'align',
				'description' => __("Set the button alignment", "spark-theme"),
				'value' => array(
					'Center' => 'center',
					'Left' => 'left',
					'Right' => 'right'
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __("CSS Animation", "spark-theme"),
				'param_name' => 'animation_name',
				'value' => $sectionTitleInstance->animation_style_list(),
				'std' => 'fadeInUp',
				'description' => __("Give the animation style name. Find a animation style name from <a href='https://daneden.github.io/animate.css/'>here</a> ", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation delay", "spark-theme"),
				'param_name' => 'animation_delay',
				'std' => '0.2s',
				'description' => __("Animation delay in seconds", "spark-theme")
			),
			array(
				'type' => 'textfield',
				'heading' => __("Animation duration", "spark-theme"),
				'param_name' => 'animation_duration',
				'std' => '1s',
				'description' => __("Animation duration in seconds", "spark-theme")
			)
		)
	));
}
