<?php 


class SparkCustomPosts {

	function __construct()
	{
		add_action( 'init', array( $this, 'spark_testimonial') );
	}



	/**
	 *
	 * Spark Testimonial Custom Post Type
	 *
	 */
	public function spark_testimonial()
	{
		$plural_slider = 'Testimonials';
		$singular_slider = 'Testimonial';

		$labels = array(
			'name'               => _x( $singular_slider , 'post type general name', 'spark-theme' ),
			'singular_name'      => _x( $singular_slider, 'post type singular name', 'spark-theme' ),
			'menu_name'          => _x( $singular_slider , 'admin menu', 'spark-theme' ),
			'name_admin_bar'     => _x( $singular_slider, 'add new on admin bar', 'spark-theme' ),
			'add_new'            => _x( 'Add New', $singular_slider, 'spark-theme' ),
			'add_new_item'       => __( 'Add New ' . $singular_slider, 'spark-theme' ),
			'new_item'           => __( 'New ' . $singular_slider, 'spark-theme' ),
			'edit_item'          => __( 'Edit ' . $singular_slider, 'spark-theme' ),
			'view_item'          => __( 'View ' . $singular_slider, 'spark-theme' ),
			'all_items'          => __( 'All ' . $plural_slider, 'spark-theme' ),
			'search_items'       => __( 'Search ' . $plural_slider, 'spark-theme' ),
			'parent_item_colon'  => __( 'Parent :', 'spark-theme' ),
			'not_found'          => __( 'No '. $plural_slider .' found.', 'spark-theme' ),
			'not_found_in_trash' => __( 'No '.$plural_slider.' found in Trash.', 'spark-theme' )
		);

		$args = array(
			'labels'             => $labels,
	        'description'        => __( 'Description.', 'spark-theme' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-businessman',
			'rewrite'            => array( 'slug' => $plural_slider, 'with_front' => true, 'pages' => true, 'feeds' => true ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title' )
		);

		register_post_type('testimonial', $args);
	}
}

$sparkCustomPostInstance = new SparkCustomPosts;