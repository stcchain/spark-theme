<?php 

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { 
	exit; 
}

// Spark theme shortcode class
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcodes-class.php';

// Spark theme title shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-section-title.php';

// Spark theme title shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-paragraph.php';

// Spark theme list shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-list-i.php';

// Spark theme list shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-slider-i.php';

// Spark theme service text block shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-service-text-block.php';

// Spark theme service text block style 2 shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-service-text-block-2.php';

// Spark theme text block shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-text-block.php';

// Spark theme step text block shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-text-block-step.php';

// Spark theme button shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-button.php';

// Spark theme position image shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-position-image.php';

// Spark theme call to action  shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-call-to-action.php';

// Spark theme team member
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-team-member.php';

// Spark theme testimonials
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-testimonials.php';

// Spark theme testimonials
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-testimonial-slider.php';

// Spark theme testimonials slider 2
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-testimonial-slider-2.php';

// Spark theme FAQ
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-faq.php';

// Spark theme pricing shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-pricing.php';

// Spark theme separator
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-separator.php';

// Spark theme spacing
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-spacing.php';

// Spark theme clouds
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-clouds.php';

// Spark theme Domain Search Form 1
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-search-domain-1.php';

// Spark theme Domain Search Form 2
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-search-domain-2.php';

// Spark theme google map shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-google-map.php';

// Spark theme image shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-image.php';

// Spark theme subscriber form shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-subscribe-form-one.php';

// Spark theme subscriber form shortcode
require_once plugin_dir_path(__FILE__) . '/shortcodes/shortcode-subscribe-form-two.php';

